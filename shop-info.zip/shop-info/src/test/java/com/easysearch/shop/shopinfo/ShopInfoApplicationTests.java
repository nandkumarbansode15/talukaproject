package com.easysearch.shop.shopinfo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShopInfoApplicationTests {

	@Test
	void contextLoads() {
	}

}
