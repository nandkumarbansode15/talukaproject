package com.easysearch.discoveryserver.shopdiscoveryserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShopDiscoveryServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(ShopDiscoveryServerApplication.class, args);
	}

}
