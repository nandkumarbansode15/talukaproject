package com.easysearch.discoveryserver.shopdiscoveryserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShopDiscoveryServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
